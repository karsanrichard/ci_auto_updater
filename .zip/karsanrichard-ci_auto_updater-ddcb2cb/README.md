# ci_auto_updater
Test for auto updater
